#!/usr/bin/python
# _*_ coding: utf-8 _*_

#
# Belong to Hailong;
#HOST = "10.134.30.154:10171"
HOST = "weixin.appsearch.m.sogou.com"

#
# Belong to Hailong;
MONGO_USER_INFO = "10.12.143.209"

#
# Belong to Gary;
MONGO_ARTICLE = "10.134.37.31"

#
# Default port for pymongo;
MONGO_DEFAULT_PORT = 27012

#
# Type:MySQL;
# Belong to Gary;
# ubs_black_app_weixin_check
#MYSQL_APP_WEIXIN_CHECK_HOST = "mysql01.ctc"
MYSQL_APP_WEIXIN_CHECK_HOST = "10.134.67.230"
MYSQL_APP_WEIXIN_CHECK_USER = "app_weixin"
MYSQL_APP_WEIXIN_CHECK_PWD  = "app_weixin"
MYSQL_APP_WEIXIN_CHEKC_DB   = "ubs_spider_black"
MYSQL_APP_WEIXIN_CHECK_CHARSET = "gbk"
MYSQL_APP_WEIXIN_CHECK_TABLE = "ubs_black_app_weixin_check"

#
# Type: MySQL;
#   - db_weixin
#   - t_account_manager
MYSQL_OA_HOST = "10.134.37.32"
MYSQL_OA_USER = "zhengtong"
MYSQL_OA_PWD  = "zhengtong"
MYSQL_OA_DB   = "db_weixin"
MYSQL_OA_CHARSET = "gbk"
MYSQL_OA_TABLE = "t_account_manager"
#
OPENID_PREFIX = "http://weixin.sogou.com/gzh?openid="

#
# Type: MySQL;
#   - db_weixin
#   - t_shenhe_1
MYSQL_CWEB = "10.134.37.32"
MYSQL_CWEB_USER = "zhengtong"
MYSQL_CWEB_PWD = "zhengtong"
MYSQL_DB_WEIXIN = "db_weixin"
MYSQL_DB_WEIXIN_CHARSET = "gbk"
MYSQL_ARTICLE_TABLE = "t_shenhe_1"
