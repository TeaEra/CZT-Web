-- cweb
-- db_weixin
-- t_shenhe_1
ALTER TABLE t_shenhe_1 ADD img_enabled INT(5) UNSIGNED DEFAULT 0 NOT NULL;
