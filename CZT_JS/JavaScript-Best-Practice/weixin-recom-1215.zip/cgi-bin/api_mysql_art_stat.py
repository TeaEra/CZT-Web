#!/usr/bin/python
# _*_ coding: utf-8 _*_

import CONST
import UTIL
from UTIL import ADMIN_WEIXIN_CHECK
from UTIL import TOTAL_STAT
#
import MySQLdb
import MySQLdb.cursors
import cgi
import cgitb
import urllib
import json
import copy


cgitb.enable()
fs = cgi.FieldStorage()
#


def get_res():
    #
    sql_where = TOTAL_STAT.get_where_from_fs(fs)
    #
    res = dict()
    res["stat"] = list()
    #
    try:
        conn, cur = ADMIN_WEIXIN_CHECK.get_conn_for_mysql_art()
        table = ADMIN_WEIXIN_CHECK.get_table()
        #
        sql_select = "select topic1, status from " + table
        sql_total = sql_select + sql_where
        #
        #print sql_total
        cur.execute(sql_total)
        all_data = cur.fetchall()
        #
        all_stat = dict()
        for each_row in all_data:
            #
            topic1 = each_row["topic1"]
            status = each_row["status"]
            #
            if topic1 == "":
                topic1 = "NULL"
            #
            if not topic1 in all_stat:
                all_stat[topic1] = dict()
                #
                all_stat[topic1]["pass"] = 0
                all_stat[topic1]["fail"] = 0
            #
            if status == 1:
                all_stat[topic1]["pass"] += 1
            elif status == 2:
                all_stat[topic1]["fail"] += 1
        #
        total_total = 0
        total_pass = 0
        total_fail = 0
        types = all_stat.keys()
        types.sort()
        for each_type in types:
            #
            temp_pass = all_stat[each_type]["pass"]
            temp_fail = all_stat[each_type]["fail"]
            temp_total = temp_pass + temp_fail
            temp_ratio = 100.0 * temp_pass / temp_total
            #
            temp_list = list()
            temp_list.append(each_type)
            temp_list.append(temp_total)
            temp_list.append(temp_pass)
            temp_list.append(temp_fail)
            temp_list.append("%.2f" % temp_ratio)
            #
            res["stat"].append(temp_list)
            #
            total_total += temp_total
            total_pass += temp_pass
            total_fail += temp_fail
        #
        total_ratio = 100.0 * total_pass / total_total
        res["stat"].append(["all", total_total, total_pass, total_fail, "%.2f" % total_ratio])
        #
        cur.close()
        conn.close()
        #
        UTIL.append_result_ok(res)
    except Exception, e:
        #
        UTIL.append_result_error(res, e)
    #
    return res


print "Content-Type: application/json; charset=utf-8"
print
print(json.dumps(get_res()))
