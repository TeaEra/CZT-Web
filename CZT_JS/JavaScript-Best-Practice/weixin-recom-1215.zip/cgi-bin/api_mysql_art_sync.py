#!/usr/bin/python
# _*_ coding: utf-8 _*_


import os, sys, string
import pymongo
import time
import MySQLdb
from datetime import datetime
#
import cgi
import cgitb
import json
import time
#
import CONST
import UTIL
from UTIL import WEIXIN_CHECK
from UTIL import ADMIN_WEIXIN_CHECK


cgitb.enable()
fs = cgi.FieldStorage()
#


def sync():
    #
    res = dict()
    res["res"] = list()
    #
    try:
        #
        conn, cursor = ADMIN_WEIXIN_CHECK.get_conn_for_mysql_art()
        table = ADMIN_WEIXIN_CHECK.get_table()
        #
        list_res = []
        select_sql = "select url, status, topic1, keywords, title, img_disabled, rank_type, top_end_time from " + table + " where sync_status=1"    
        num = cursor.execute(select_sql)
        for row in cursor.fetchall():
            list_res.append(row)
        #return list_res
        #print len(list_res)
        mysql_size = len(list_res)
        #
        ######
        #
        offline_match_size = 0
        #
        connection = pymongo.Connection('10.134.37.31', 27012)
        db = connection.WeiXinRecom
        collection = db.weixin_articles
        for each_res in list_res:
            #
            url = each_res["url"]
            status = each_res["status"]
            topic1 = each_res["topic1"]
            keywords = each_res["keywords"]
            title = each_res["title"]
            img_disabled = each_res["img_disabled"]
            rank_type = each_res["rank_type"]
            top_end_time = each_res["top_end_time"]
            #
            topic1 = topic1.encode("gbk", "ignore")
            keywords = keywords.encode("gbk", "ignore")
            title = title.encode("gbk", "ignore")
            #
            keywords_list = list()
            for each_keyword in keywords.split("|"):
                if each_keyword != "":
                    temp_list = list()
                    temp_list.append(each_keyword)
                    temp_list.append(1)
                    #
                    keywords_list.append(temp_list)
            #
            ts = int(round(time.time()))
            #
            mongo_art = collection.find_one({"url": url})
            if mongo_art is None:
                continue
            offline_match_size += 1
            #
            collection.update(
                {"url":url}, 
                {"$set": {
                        "status":status, 
                        "topic1":topic1, 
                        "keywords": keywords_list,
                        "title": title,
                        "sync_time": ts,
                        "img_disabled": img_disabled,
                        "rank_type": rank_type,
                        "top_end_time": int(time.mktime(top_end_time.timetuple())) if not top_end_time is None else None
                    }
                }, 
                upsert=False, 
                multi=False
            )
        #
        connection.close()
        '''
        '''
        ######
        ######
        # Another mongodb
        #
        online_match_size = 0
        #
        connection = pymongo.Connection('10.144.26.114', 17016)
        db = connection.WeiXinRecom
        collection = db.weixin_articles
        count = 0
        for each_res in list_res:
            #
            url = each_res["url"]
            status = each_res["status"]
            topic1 = each_res["topic1"]
            keywords = each_res["keywords"]
            title = each_res["title"]
            img_disabled = each_res["img_disabled"]
            rank_type = each_res["rank_type"]
            top_end_time = each_res["top_end_time"]
            #
            topic1 = topic1.encode("gbk", "ignore")
            keywords = keywords.encode("gbk", "ignore")
            title = title.encode("gbk", "ignore")
            #
            keywords_list = list()
            for each_keyword in keywords.split("|"):
                if each_keyword != "":
                    temp_list = list()
                    temp_list.append(each_keyword)
                    temp_list.append(1)
                    #
                    keywords_list.append(temp_list)
            #
            ts = int(round(time.time()))
            #
            mongo_art = collection.find_one({"url": url})
            if mongo_art is None:
                continue
            online_match_size += 1
            _id = mongo_art["_id"]
            #
            collection.update(
                {"_id": _id}, 
                {"$set": {
                        "status":status, 
                        "topic1":topic1, 
                        "keywords": keywords_list,
                        "title": title,
                        "sync_time": ts,
                        "img_disabled": img_disabled,
                        "rank_type": rank_type,
                        "top_end_time": int(time.mktime(top_end_time.timetuple())) if not top_end_time is None else None
                    }
                }, 
                upsert=False, 
                multi=False
            )
            #
            count += 1
            if count % 200 == 0:
                #print ">>> " + str(count)
                #
                connection.close()
                connection = pymongo.Connection('10.144.26.114', 17016)
                db = connection.WeiXinRecom
                collection = db.weixin_articles
        #print ">>> " + str(count)
        #
        connection.close()
        ######
        #
        update_sql = "update " + table + " set sync_status = 2 where sync_status = 1"
        cursor.execute(update_sql)
        '''
        '''
        conn.close()
        #
        UTIL.append_result_ok(res)
        #
        res["stat"] = dict()
        res["stat"]["mysql_size"] = mysql_size
        res["stat"]["offline_match_size"] = offline_match_size
        res["stat"]["online_match_size"] = online_match_size
    except Exception, e:
        #
        UTIL.append_result_error(res, e)
    #
    return res


print "Content-Type: application/json; charset=utf-8"
print
print(json.dumps(sync()))
