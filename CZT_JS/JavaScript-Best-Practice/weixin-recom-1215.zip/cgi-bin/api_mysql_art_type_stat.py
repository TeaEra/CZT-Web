#!/usr/bin/python
# _*_ coding: utf-8 _*_

import CONST
import UTIL
from UTIL import ADMIN_WEIXIN_CHECK
from UTIL import TYPE_STAT
#
import MySQLdb
import MySQLdb.cursors
import cgi
import cgitb
import urllib
import json
import copy


cgitb.enable()
fs = cgi.FieldStorage()
#


def get_res():
    #
    sql_where = TYPE_STAT.get_where_from_fs(fs)
    #
    res = dict()
    res["stat"] = list()
    #
    try:
        conn, cur = ADMIN_WEIXIN_CHECK.get_conn_for_mysql_art()
        table = ADMIN_WEIXIN_CHECK.get_table()
        #
        sql_select = "select status, modify_time from " + table
        sql_total = sql_select + sql_where
        sql_total += " order by modify_time"
        #
        #print sql_total
        cur.execute(sql_total)
        all_data = cur.fetchall()
        #print all_data
        #
        type_stat = dict()
        for each_row in all_data:
            #
            status = each_row["status"]
            modify_time = each_row["modify_time"]
            #
            formatted_mt = modify_time.strftime("%Y-%m-%d")
            #
            if not formatted_mt in type_stat:
                type_stat[formatted_mt] = dict()
                #
                type_stat[formatted_mt]["pass"] = 0
                type_stat[formatted_mt]["fail"] = 0
            #
            if status == 1:
                type_stat[formatted_mt]["pass"] += 1
            elif status == 2:
                type_stat[formatted_mt]["fail"] += 1
        #
        mts = type_stat.keys()
        mts.sort()  #  sort!!!
        for each_mt in mts:
            #
            temp_pass = type_stat[each_mt]["pass"]
            temp_fail = type_stat[each_mt]["fail"]
            temp_total = temp_pass + temp_fail
            temp_ratio = 100.0 * temp_pass / temp_total
            #
            temp_list = list()
            temp_list.append(each_mt)
            temp_list.append(temp_total)
            temp_list.append(temp_pass)
            temp_list.append(temp_fail)
            temp_list.append("%.2f" % temp_ratio)
            #
            res["stat"].append(temp_list)
        #
        cur.close()
        conn.close()
        #
        UTIL.append_result_ok(res)
    except Exception, e:
        #
        UTIL.append_result_error(res, e)
    #
    return res


print "Content-Type: application/json; charset=utf-8"
print
print(json.dumps(get_res()))
