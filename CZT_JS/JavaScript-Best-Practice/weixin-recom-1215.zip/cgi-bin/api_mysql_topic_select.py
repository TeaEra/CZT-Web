#!/usr/bin/python
# _*_ coding: utf-8 _*_

import CONST
import UTIL
from UTIL import ADMIN_TOPIC
#
import MySQLdb
import MySQLdb.cursors
import cgi
import cgitb
import urllib
import json
import copy


cgitb.enable()
fs = cgi.FieldStorage()
#


def get_res():
    #
    res = dict()
    res["topic"] = list()
    #
    try:
        conn, cur = ADMIN_TOPIC.get_conn_for_mysql_topic()
        table = ADMIN_TOPIC.get_table()
        select_sql = "select * from " + table
        #
        all_data = UTIL.run_conn_select(cur, select_sql)
        #
        for row in all_data:
            res["topic"].append(UTIL.get_dict_in_utf8(row))
        #
        cur.close()
        conn.close()
        #
        UTIL.append_result_ok(res)
    except Exception, e:
        #
        UTIL.append_result_error(res, e)
    #
    return res


print "Content-Type: application/json; charset=utf-8"
print
print(json.dumps(get_res()))
