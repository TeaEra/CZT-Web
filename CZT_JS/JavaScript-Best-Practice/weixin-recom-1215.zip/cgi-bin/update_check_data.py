#!/usr/bin/python
# _*_ coding: utf-8 _*_


import os, sys, string
import pymongo
import time
import MySQLdb
from datetime import datetime

# http://mp.weixin.qq.com/
begin = len("http://mp.weixin.qq.com/s?__biz=")
map_ku_info = {}
map_zhuanfa = {}
map_yuedu = {}

now = datetime.now()
print now
conn = MySQLdb.connect(host="mysql01.ctc", user="app_weixin", passwd="app_weixin", db="ubs_spider_black", charset="gbk")
cursor = conn.cursor()

list_res = []
select_sql = "select url, status from ubs_black_app_weixin_check where sync_status=2"
    
num = cursor.execute(select_sql)

for row in cursor.fetchall():
    list_res.append(row)


now = int(time.time())

connection = pymongo.Connection('10.134.37.31', 27012)
db = connection.WeiXinRecom
collection = db.weixin_articles

for (url, status) in list_res:
    collection.update({"url":url}, {"$set":{"status":status}}, False, False)

connection.close()

update_sql = "update ubs_black_app_weixin_check set sync_status = 4 where sync_status = 2"
cursor.execute(update_sql)
conn.close()


