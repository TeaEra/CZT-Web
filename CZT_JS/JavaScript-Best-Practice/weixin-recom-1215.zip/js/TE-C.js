/**
 * by chenzhengtong @ 2014-11-18
 */

(function () {
    "use strict";

    //
    window.TEC = window.TEC || {};

    //
    window.TEC.effect_click_nav_btn = function (nav_btn_list) {
        //
        _.forEach(nav_btn_list, function (id) {
            $(id).bind(
                "click",
                function () {
                    _.forEach(nav_btn_list, function (each_id) {
                        $(each_id).removeClass("active");
                    });
                    $(this).addClass("active");
                }
            );
        });
    };

    /**
     * Effect:
     *   loading while ajax call;
     */
    window.TEC.add_loading_effect = function () {
        //
        // Spin settings;
        var opts = {
          lines: 13, // The number of lines to draw
          length: 20, // The length of each line
          width: 10, // The line thickness
          radius: 30, // The radius of the inner circle
          corners: 1, // Corner roundness (0..1)
          rotate: 0, // The rotation offset
          direction: 1, // 1: clockwise, -1: counterclockwise
          color: '#000', // #rgb or #rrggbb or array of colors
          speed: 1, // Rounds per second
          trail: 60, // Afterglow percentage
          shadow: false, // Whether to render a shadow
          hwaccel: false, // Whether to use hardware acceleration
          className: 'spinner', // The CSS class to assign to the spinner
          zIndex: 2e9, // The z-index (defaults to 2000000000)
          top: '50%', // Top position relative to parent
          left: '50%' // Left position relative to parent
        };
        var spin_target = document.getElementsByTagName('body')[0];
        var spinner = new Spinner(opts);
        // 
        // Add ajax loading effect;
        $(document).on({
            ajaxStart: function() {
                $("#id-div-mask").addClass("display-block");
                spinner.spin(spin_target);
            },
            ajaxStop: function() {
                spinner.spin();
                $("#id-div-mask").removeClass("display-block");
            }    
        });
    };

    /**
     * Effect:
     *   scroll to top;
     */
    window.TEC.effect_scroll_top = function () {
        //
        $(window).scroll(function () {
            if ($(this).scrollTop() >= window.screen.availHeight/3) {
                $("#id-btn-scroll-top").fadeIn();
            }
            else {
                $("#id-btn-scroll-top").fadeOut();
            }
        });
        $("#id-btn-scroll-top").bind("click", window.TEC.action_scroll_top);
    };

    /**
     * Action:
     *   action for add_scroll_top_effect;
     */
    window.TEC.action_scroll_top = function () {
        $('html, body').animate({scrollTop : 0},800);
        return false;
    };

    /**
     * Original js;
     */
    window.TEC.get_date = function (str_date) {
        if (! str_date) {
            return "";
        }
        var sd_list = str_date.split("");  // should be "" here
        var pos = sd_list.indexOf(" ");  // a space here;
        if (pos !== -1) {
            sd_list.splice(pos, 1, "T");
        }
        return new Date(sd_list.join(""));  // should be "" here
    };

    /**
     * Action:
     */
    window.TEC.get_val_for_dt_local = function (dt) {
        //
        var dt_obj = dt ? new Date(dt) : new Date();
        var year = dt_obj.getUTCFullYear();
        var month = dt_obj.getUTCMonth() + 1;
        var day = dt_obj.getUTCDate();
        var hour = dt_obj.getHours();
        var min = dt_obj.getMinutes();
        //
        return year + "-" + (month<10 ? "0"+month : month) + "-" + (day<10 ? "0"+day : day) + "T" + (hour<10 ? "0"+hour : hour) + ":" + (min<10 ? "0"+min : min);
    };


    /**
     */
    window.TEC.get_str_date_utc = function (in_date, is_with_hms) {
        if (! in_date) {
            return "";
        }
        var y = in_date.getUTCFullYear();
        var m = in_date.getUTCMonth()+1;
        var d = in_date.getUTCDate();
        var hour = in_date.getUTCHours();
        var min = in_date.getUTCMinutes();
        var sec = in_date.getUTCSeconds();
        //
        var str_date_utc = 
            y
            + "-" + (m<10 ? "0"+m : m) 
            + "-" + (d<10 ? "0"+d : d);
        if (is_with_hms) {
            str_date_utc += "T" 
                + (hour<10 ? "0"+hour : hour) 
                + ":" + (min<10 ? "0"+min : min)
                + ":" + (sec<10 ? "0"+sec : sec);
        }
        return str_date_utc;
    };

})();
