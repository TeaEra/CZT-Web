/**
 * Created by TeaEra @ 2014-11-14
 */

(function () {
    "use strict";

    //
    window.TEV = window.TEV || {};

    //
    window.TEV.get_cols = function (num1, num2, num3, num4) {
        return "col-lg-" + (num1 ? num1: "1") 
            + " col-md-" + (num2 ? num2: num1)
            + " col-sm-" + (num3 ? num3: num1)
            + " col-xs-" + (num4 ? num4: num1);
    };

    //
    window.TEV.get_cols_offset = function (num1, num2, num3, num4) {
        return "col-lg-offset-" + (num1 ? num1: "1") 
            + " col-md-offset-" + (num2 ? num2: num1) 
            + " col-sm-offset-" + (num3 ? num3: num1) 
            + " col-xs-offset-" + (num4 ? num4: num1);
    };

    //
    window.TEV.tpl_blank = _.template('\
    <!-- -->\
    <%\
    var info = arguments[0];\
    var header = info["header"];\
    var h_title = header["title"];\
    var h_set = header["settings"];\
    var content = info["content"];\
    var c_list = content["list"];\
    var c_set = content["settings"];\
    %>\
    <!-- -->\
    <div class="container">\
        <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24">\
            <!-- Here is title -->\
            <div class="row">\
            <%\
            for (var idx in h_title) {\
            %>\
                <div class="<%=window.TEV.get_cols(h_set[idx]) %>">\
                    <p><%=h_title[idx] %></p>\
                </div>\
            <%\
            }\
            %>\
            </div>\
            <!-- Here is content -->\
            <%\
            for (var idx in c_list) {\
                var each_row = c_list[idx];\
            %>\
                <hr />\
                <div class="row">\
            <%\
                for (var col_idx in each_row) {\
            %>\
                    <div class="<%=window.TEV.get_cols(c_set[col_idx]) %>">\
                        <p><%=each_row[col_idx] %></p>\
                    </div>\
            <%\
                }\
            %>\
                </div>\
            <%\
            }\
            %>\
        </div>\
    </div>\
    ');

    /**
     * navbar format:
     * {
     *  title: "",
     *  navs: [
     *      {
     *          id: "",
     *          text: ""
     *      },
     *      ...
     *  ]
     * }
     *
     */
    window.TEV.tpl_navbar = _.template('\
    <%\
    var navbar = arguments[0];\
    var brand_title = navbar["title"];\
    var navs = navbar["navs"];\
    %>\
    <!-- -->\
    <nav id="id-admin-navbar-nav" class="navbar navbar-default navbar-fixed-top" role="navigation">\
        <div class="container-fluid">\
            <!-- -->\
            <div class="navbar-header">\
                <button id="id-admin-collapsed-navbar" type="button" \
                        class="navbar-toggle collapsed" data-toggle="collapse" \
                        data-target="#id-admin-detailed-navbar">\
                    <span class="sr-only">Toggle navigation</span>\
                    <span class="icon-bar"></span>\
                    <span class="icon-bar"></span>\
                    <span class="icon-bar"></span>\
                </button>\
            </div>\
            <!-- -->\
            <div class="collapse navbar-collapse" id="id-admin-detailed-navbar">\
                <ul class="nav navbar-nav">\
                <%\
                for (var nav_idx in navs) {\
                    var nav = navs[nav_idx];\
                    var nav_id = nav["id"];\
                    var nav_text = nav["text"];\
                %>\
                    <li id="<%=nav_id %>">\
                        <a href="javascript:void(0);">\
                            <%=nav_text %>\
                        </a>\
                    </li>\
                <%\
                }\
                %>\
                </ul>\
            </div>\
        </div>\
    </nav>\
    ');

    window.TEV.tpl_pager = _.template('\
    <%\
    var info = arguments[0];\
    var curr_num = info["curr_num"];\
    var page_num = info["page_num"];\
    %>\
    <!-- -->\
    <div class="container">\
        <hr />\
        <div class="row text-center">\
            <nav>\
                <ul class="pager">\
                <%\
                if (curr_num != 0) {\
                %>\
                    <li id="id-admin-pager-previous"><a href="javascript:void(0);">上一页</a></li>\
                <%\
                }\
                %>\
                    <li>\
                    &nbsp;&nbsp;&nbsp;\
                    <div class="label-info" style="display: inline; font-size: 1.2em;">\
                        <!--<span id="id-admin-pager-curr-num"><%=curr_num+1 %></span> / <%=page_num+1 %>-->\
                        <input type="number" id="id-admin-pager-curr-num" value="<%=curr_num+1 %>" /> / <%=page_num+1 %>\
                    </div>\
                    &nbsp;&nbsp;&nbsp;\
                    </li>\
                <%\
                if (curr_num != page_num) {\
                %>\
                    <li id="id-admin-pager-next"><a href="javascript:void(0);">下一页</a></li>\
                <%\
                }\
                %>\
                </ul>\
            </nav>\
        </div>\
    </div>\
    ');

    window.TEV.tpl_toggled_filter = _.template('\
    <%\
    var info = arguments[0];\
    var is_show_bc = info["is-show-bc"] || false;\
    %>\
    <!-- -->\
    <div class="container">\
        <div class="<%=window.TEV.get_cols(24) %>">\
        <%\
        if (is_show_bc) {\
            var project = info["project"] || "";\
            var module = info["module"] || "";\
        %>\
            <!-- -->\
            <div class="row">\
                <div class="<%=window.TEV.get_cols(24) %>">\
                    <ol class="breadcrumb">\
                        <li><a href="javascript:void(0);"><%=project %></a></li>\
                        <li class="active"><%=module %></li>\
                    </ol>\
                </div>\
            </div>\
        <%\
        }\
        var panel = info["panel"];\
        var heading = panel["heading"];\
        var body = panel["body"];\
        var btns = panel["btns"];\
        var btn_reset = btns["reset"];\
        var btn_search = btns["search"];\
        var h_id = heading["id"] || "";\
        var h_txt = heading["text"] || "条件查询";\
        var b_id = body["id"];\
        var b_is_show = body["is-show"];\
        var b_rows = body["rows"];\
        %>\
            <div class="row">\
                <div class="panel panel-default">\
                    <div class="panel-heading">\
                        <h4 class="panel-title">\
                            <a id="<%=h_id %>" data-toggle="collapse" href="#<%=b_id %>"><%=h_txt %></a>\
                        </h4>\
                    </div>\
                    <div class="panel-collapse collapse <%=b_is_show ? "in" : "" %>" id="<%=b_id %>">\
                        <div class="panel-body">\
                        <%\
                        for (var row_idx in b_rows) {\
                            var each_row = b_rows[row_idx];\
                        %>\
                            <div class="row te-padding-bottom">\
                            <%\
                            for (var cpnt_idx in each_row) {\
                                var cpnt = each_row[cpnt_idx];\
                                var label = cpnt["label"] || "";\
                                var id = cpnt["id"] || "";\
                                var type = cpnt["type"] || "input";\
                                var input_type = cpnt["input-type"] || "text";\
                                var options = cpnt["options"] || "";\
                                var my_class = cpnt["class"] || "form-control";  // "class" is reserved word;\
                            %>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label class="te-padding-tb"><%=label %></label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                <%\
                                if (type === "input") {\
                                %>\
                                    <input id="<%=id %>" class="<%=my_class %>" type="<%=input_type %>" />\
                                <%\
                                } else if (type === "select") {\
                                %>\
                                    <select id="<%=id %>" class="<%=my_class %>"><%=options %></select>\
                                <%\
                                }\
                                %>\
                                </div>\
                            <%\
                            }\
                            %>\
                            </div>\
                        <%\
                        }\
                        %>\
                            <hr />\
                            <div class="row">\
                                <div class="<%=window.TEV.get_cols(24) %>">\
                                    <div class="btn-group">\
                                    <%\
                                    var btn_reset_id = btn_reset["id"] || "";\
                                    var btn_reset_text = btn_reset["text"] || "恢复默认值";\
                                    var btn_reset_class = btn_reset["class"] || "btn btn-default";\
                                    var btn_search_id = btn_search["id"] || "";\
                                    var btn_search_text = btn_search["text"] || "开始查询";\
                                    var btn_search_class = btn_search["class"] || "btn btn-primary";\
                                    %>\
                                        <button class="<%=btn_reset_class %>" \
                                            id="<%=btn_reset_id %>"><%=btn_reset_text %></button>\
                                        <button class="<%=btn_search_class %>" \
                                            id="<%=btn_search_id %>"><%=btn_search_text %></button>\
                                    </div>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                </div>\
            </div>\
        </div>\
    </div>\
    ');

    window.TEV.tpl_list = _.template('\
    <%\
    var info = arguments[0];\
    var total_cols = info["total-cols"] || "12";\
    var total_cs = window.TEV.get_cols(total_cols);\
    var total_operations = info["total-operations"] || {};\
    var to_content = total_operations["content"] || "";\
    var total_head = info["total-head"] || {};\
    var head_column = total_head["column"] || [];\
    %>\
    <!-- -->\
    <div class="container">\
        <div class="<%=total_cs %>">\
            <div id="id-tpl-list-total-operations">\
                <%=to_content %>\
            </div>\
            <br />\
            <br />\
            <br />\
            <div class="row">\
            <%\
            for (var idx in head_column) {\
                var each_column = head_column[idx];\
                var each_text = each_column["text"] || "";\
                var each_width = each_column["width"];\
            %>\
                <div class="<%=window.TEV.get_cols(each_width) %>">\
                    <p><%=each_text %></p>\
                </div>\
            <%\
            }\
            %>\
            </div>\
            <div id="id-tpl-list-content">\
            </div>\
        </div>\
    </div>\
    ');

    window.TEV.tpl_list_content = _.template('\
    <%\
    var info = arguments[0];\
    var column = info["column"];\
    var data = info["data"];\
    for (var idx in data) {\
        var row = data[idx];\
    %>\
    <hr />\
    <div class="row">\
    <%\
        for (var col_idx in column) {\
            var col = column[col_idx];\
            var field = col["field"];\
            var width = col["width"];\
            var type = col["type"];\
    %>\
            <div class="<%=window.TEV.get_cols(width) %>">\
    <%\
            if (field !== "operations") {\
                var field_value = row[field] || "";\
                if (type === "string") {\
    %>\
                    <p><%=field_value %></p>\
    <%\
                } else if (type === "date") {\
                } else if (type === "link") {\
                }\
            } else {\
                var opers;\
    %>\
                    <button id="" class=""></button>\
    <%\
            }\
    %>\
            </div>\
    <%\
        }\
    %>\
    </div>\
    <%\
    }\
    %>\
    ');

})();
