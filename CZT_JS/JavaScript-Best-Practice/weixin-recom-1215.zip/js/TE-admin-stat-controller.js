/**
 * by chenzhengtong @ 2014-11-17;
 */

(function () {
    "use strict";

    //
    window.TEC = window.TEC || {};

    /**
     * stat navbar;
     */
    window.TEC.show_stat_navbar = function () {
        //
        window.TEC.add_loading_effect();
        //
        window.TEC.effect_scroll_top();
        //
        $(window.TEIDS.STAT_NAVBAR).html(
            window.TEV.tpl_navbar(window.objs.stat_navbar)
        );
        //
        // Bind events;
        $(window.TEIDS.NAV_STAT_TOTAL).bind(
            "click",
            window.TEC.show_stat_total
        );
        $(window.TEIDS.NAV_STAT_TYPE).bind(
            "click",
            window.TEC.show_stat_type
        );
        //
        var nav_btn_list = new Array();
        nav_btn_list.push(window.TEIDS.NAV_STAT_TOTAL);
        nav_btn_list.push(window.TEIDS.NAV_STAT_TYPE);
        window.TEC.effect_click_nav_btn(nav_btn_list);
    };

    /**************************************************************************/
    /*** TOTAL statistics begin ***/

    /**
     * statistics in total;
     */
    window.TEC.show_stat_total = function () {
        //
        $(window.TEIDS.STAT_FILTER).html(
            window.TEV.total_stat_filter()
        );
        //
        $(window.TEIDS.TOTAL_FILTER_SEARCH).bind(
            "click",
            window.TEC.search_total_filter
        );
        //
        $(window.TEIDS.TOTAL_FILTER_RESET).bind(
            "click",
            window.TEC.reset_total_filter
        );
        //
        window.TEC.search_total_filter();
    };

    /**
     */
    window.TEC.search_total_filter = function () {
        //
        var info = window.TEC.data_from_total_filter();
        //
        window.TEC.api_stat_total(
            info,
            window.TEC.sa_for_api_stat_total
        );
    };

    /**
     */
    window.TEC.reset_total_filter = function () {
        //
        $(window.TEIDS.TOTAL_FILTER_TIME_START).val("");
        $(window.TEIDS.TOTAL_FILTER_TIME_END).val("");
    };

    /**
     */
    window.TEC.data_from_total_filter = function () {
        //
        // from filter;
        var modify_time_start = $(window.TEIDS.TOTAL_FILTER_TIME_START).val();
        var modify_time_end = $(window.TEIDS.TOTAL_FILTER_TIME_END).val();
        //
        var info = {
            "modify_time_start": modify_time_start,
            "modify_time_end": modify_time_end
        };
        return info;
    };
    
    /**
     */
    window.TEC.data_for_api_stat_total = function (info) {
        //
        var mt_start = info["modify_time_start"];
        var mt_end = info["modify_time_end"];
        //
        var params = new Array();
        mt_start ? params.push("modify_time_start=" + mt_start) : "";
        mt_end ? params.push("modify_time_end=" + mt_end) : "";
        //
        if (params.length === 0) {
            return "me=me";
        }
        return params.join("&");
    };

    /**
     * SA:
     */
    window.TEC.sa_for_api_stat_total = function (data) {
        //
        var stat_data = {
            "thead": ["", "总审核量", "审核通过量", "审核不通过量", "审核通过率(%)"],
            "tbody": data["stat"]
        };
        //
        $(window.TEIDS.STAT_MC).html(
            window.TEV.tpl_stat_content(stat_data)
        );
        //
        $(window.TEIDS.STAT_CHART).html("");
    };

    /**
     * API:
     */
    window.TEC.api_stat_total = function (info, sa_func) {
        $.ajax({
            //url: "js/test-total-stat.json",
            url: "cgi-bin/api_mysql_art_stat.py",
            type: "post",
            data: window.TEC.data_for_api_stat_total(info),
            dataType: "json",
            success: function (data, status, jqxhr) {
                sa_func(data);
            },
            error: function (jqxhr, status, error) {
                alert(error);
            }
        });

    };


    /*** TOTAL statistics end ***/
    /**************************************************************************/

    /**************************************************************************/
    /*** TYPE statistics begin ***/

    /**
     * statistics by type;
     */
    window.TEC.show_stat_type = function (info) {
        //
        $(window.TEIDS.STAT_FILTER).html(
            window.TEV.type_stat_filter()
        );
        window.TEC.api_all_verifying_types(
            window.TEC.sa_for_api_all_verifying_types
        );
        //
        $(window.TEIDS.TYPE_FILTER_SEARCH).bind(
            "click",
            window.TEC.search_type_filter
        );
        //
        $(window.TEIDS.TYPE_FILTER_RESET).bind(
            "click",
            window.TEC.reset_type_filter
        );
        //
        window.TEC.search_type_filter();
    };

    /**
     */
    window.TEC.search_type_filter = function () {
        //
        var info = window.TEC.data_from_type_filter();
        //
        window.TEC.api_stat_type(
            info,
            window.TEC.sa_for_api_stat_type
        );
    };

    /**
     */
    window.TEC.reset_type_filter = function () {
        //
        $(window.TEIDS.TYPE_FILTER_TYPE).val("-1");
        $(window.TEIDS.TYPE_FILTER_TIME_START).val("");
        $(window.TEIDS.TYPE_FILTER_TIME_END).val("");
    };

    /**
     */
    window.TEC.data_from_type_filter = function () {
        //
        // from filter;
        var type = $(window.TEIDS.TYPE_FILTER_TYPE).val();
        var modify_time_start = $(window.TEIDS.TYPE_FILTER_TIME_START).val();
        var modify_time_end = $(window.TEIDS.TYPE_FILTER_TIME_END).val();
        //
        var info = {
            "type": type,
            "modify_time_start": modify_time_start,
            "modify_time_end": modify_time_end
        };
        return info;
    };
    
    /**
     */
    window.TEC.data_for_api_stat_type = function (info) {
        //
        var type = info["type"];
        var mt_start = info["modify_time_start"];
        var mt_end = info["modify_time_end"];
        //
        var params = new Array();
        type ? params.push("type=" + type) : "";
        mt_start ? params.push("modify_time_start=" + mt_start) : "";
        mt_end ? params.push("modify_time_end=" + mt_end) : "";
        //
        if (params.length === 0) {
            return "me=me";
        }
        return params.join("&");
    };

    /**
     * SA:
     */
    window.TEC.sa_for_api_stat_type = function (return_data) {
        //
        var data = {
            "thead": ["", "总审核量", "审核通过量", "审核不通过量", "审核通过率(%)"],
            "tbody": return_data["stat"]
        };
        //
        $(window.TEIDS.STAT_MC).html(
            window.TEV.tpl_stat_content(data)
        );
        //
        var cats = new Array();
        _.forEach(data["tbody"], function (each_day) {
            cats.push(each_day[0]);
        });
        var ratios = new Array();
        _.forEach(data["tbody"], function (each_day) {
            ratios.push(parseFloat(each_day[4]));
        });
        var totals = new Array();
        _.forEach(data["tbody"], function (each_day) {
            totals.push(parseInt(each_day[1]));
        });
        var passes = new Array();
        _.forEach(data["tbody"], function (each_day) {
            passes.push(parseInt(each_day[2]));
        });
        var fails = new Array();
        _.forEach(data["tbody"], function (each_day) {
            fails.push(parseInt(each_day[3]));
        });
        //
        /*
        $(window.TEIDS.STAT_CHART).highcharts({
            title: {
                text: "Daily statistics",
                x: -20
            },
            xAxis: {
                categories: cats,
            },
            yAxis: [
            {
                title: {
                    text: "Article number"
                }
            },
            {
                title: {
                    text: "Ratio (%)"
                },
                plotLines: [
                    {
                        value: 0,
                        width: 1,
                        color: "#808080"
                    }
                ],
                opposite: true
            }
            ],
            series: [
                {
                    yAxis: 1,
                    name: "ratio",
                    data: ratios
                },
                {
                    name: "total num",
                    data: totals
                },
                {
                    name: "pass num",
                    data: passes
                },
                {
                    name: "fail num",
                    data: fails
                }
            ]
        });
        */
        $(window.TEIDS.STAT_CHART).highcharts({
            title: {
                text: "类别统计",
                x: -20
            },
            xAxis: {
                categories: cats,
            },
            yAxis: [
            {
                title: {
                    text: "文章数"
                }
            },
            {
                title: {
                    text: "过审率 (%)"
                },
                plotLines: [
                    {
                        value: 0,
                        width: 1,
                        color: "#808080"
                    }
                ],
                opposite: true
            }
            ],
            series: [
                {
                    yAxis: 1,
                    name: "过审率",
                    data: ratios
                },
                {
                    name: "总审核量",
                    data: totals
                },
                {
                    name: "审核通过量",
                    data: passes
                },
                {
                    name: "审核不通过量",
                    data: fails
                }
            ]
        });
    };

    /**
     * API:
     */
    window.TEC.api_stat_type = function (info, sa_func) {
        $.ajax({
            //url: "js/test-type-stat.json",
            url: "cgi-bin/api_mysql_art_type_stat.py",
            type: "post",
            data: window.TEC.data_for_api_stat_type(info),
            dataType: "json",
            success: function (data, status, jqxhr) {
                sa_func(data);
            },
           error: function (jqxhr, status,error) {
                alert(error);
            }
        });
    };
    
    /**
     * SA:
     */
    window.TEC.sa_for_api_all_verifying_types = function (data) {
        //
        var all_types = data["all_types"];
        //
        var valid_types = new Array();
        for (var idx in all_types) {
            //
            var curr_type = all_types[idx]["topic1"];
            //
            // '' is also valid type;
            valid_types.push(curr_type === "" ? "NULL" : curr_type);
        }
        //
        var from_list = valid_types;
        var out_html = "";
        //
        out_html += "<option value=\"-1\">all</option>";
        //
        for (var idx in from_list) {
            out_html += "<option value=\"" + from_list[idx] + "\">" + from_list[idx] + "</option>";
        }
        //
        //$(window.TEIDS.TYPE_FILTER_TYPE_LIST).html(out_html);
        $(window.TEIDS.TYPE_FILTER_TYPE).html(out_html);
    };

    /**
     * API:
     *   all_types in verifying;
     */
    window.TEC.api_all_verifying_types = function (sa_func) {
        $.ajax({
            url: "cgi-bin/api_mysql_art_stat_all_verifying_types.py",
            type: "post",
            //
            async: false,
            //
            data: "",
            dataType: "json",
            success: function (data, status, jqxhr) {
                sa_func(data);
            },
            error: function (jqxhr, status, error) {
                alert(error);
            }
        });
    };

    /*** TYPE statistics end ***/
    /**************************************************************************/

})();
