/**
 * by chenzhengtong @ 2014-11-17;
 */

(function () {
    "use strict";

    //
    window.TEIDS = window.TEIDS || {};
    window.objs = window.objs || {};

    /**************************************************************************/
    window.TEIDS.STAT_NAVBAR = "#id-admin-stat-navbar";
    window.TEIDS.NAV_STAT_TOTAL = "#id-stat-total";
    window.TEIDS.NAV_STAT_TYPE = "#id-stat-type";
    //
    window.TEIDS.STAT_FILTER = "#id-admin-stat-filter";
    window.TEIDS.STAT_MC = "#id-admin-stat-main-content";
    window.TEIDS.STAT_CHART = "#id-admin-stat-chart";
    //
    // total filter:
    window.TEIDS.TOTAL_FILTER_TIME_START = "#id-total-stat-filter-modify-time-start";
    window.TEIDS.TOTAL_FILTER_TIME_END = "#id-total-stat-filter-modify-time-end";
    window.TEIDS.TOTAL_FILTER_SEARCH = "#id-total-stat-filter-search";
    window.TEIDS.TOTAL_FILTER_RESET = "#id-total-stat-filter-reset";
    //
    // type filter:
    window.TEIDS.TYPE_FILTER_TYPE = "#id-type-stat-filter-type";
    window.TEIDS.TYPE_FILTER_TYPE_LIST = "#id-type-stat-filter-type-list";
    window.TEIDS.TYPE_FILTER_TIME_START = "#id-type-stat-filter-modify-time-start";
    window.TEIDS.TYPE_FILTER_TIME_END = "#id-type-stat-filter-modify-time-end";
    window.TEIDS.TYPE_FILTER_SEARCH = "#id-type-stat-filter-search";
    window.TEIDS.TYPE_FILTER_RESET = "#id-type-stat-filter-reset";

    /**************************************************************************/
    window.objs.stat_navbar = {
        "title": "审核统计平台",
        "navs": [
            {
                "id": "id-stat-total",
                "text": "总体统计"
            },
            {
                "id": "id-stat-type",
                "text": "类别统计"
            }
        ]
    };

    //
    window.TEC.show_stat_navbar();
    $(window.TEIDS.NAV_STAT_TOTAL).click();
})();
