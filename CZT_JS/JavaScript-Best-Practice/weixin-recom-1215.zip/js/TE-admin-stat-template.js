/**
 * by chenzhengtong @ 2014-11-17;
 */

(function () {
    "use strict";

    //
    window.TEV = window.TEV || {};

    //
    window.TEV.total_stat_filter = _.template('\
    <br />\
    <div class="container">\
        <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24">\
            <div class="row">\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <label class="te-padding-tb">审核时间起始点:</label>\
                </div>\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <input id="id-total-stat-filter-modify-time-start" \
                        class="form-control" type="date" />\
                </div>\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <label class="te-padding-tb">审核时间结束点:</label>\
                </div>\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <input id="id-total-stat-filter-modify-time-end" \
                        class="form-control" type="date" />\
                </div>\
            </div>\
            <br />\
            <div class="row">\
                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">\
                    <button class="btn btn-default" id="id-total-stat-filter-reset">\
                        恢复默认值\
                    </button>\
                    <button class="btn btn-primary" id="id-total-stat-filter-search">\
                        开始查询\
                    </button>\
                </div>\
            </div>\
        </div>\
    </div>\
    <hr />\
    ');

    //
    window.TEV.type_stat_filter = _.template('\
    <br />\
    <div class="container">\
        <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24">\
            <div class="row">\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <label class="te-padding-tb">类别:</label>\
                </div>\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <!--\
                    <input id="id-type-stat-filter-type" class="form-control" list="id-type-stat-filter-type-list"/>\
                    <datalist id="id-type-stat-filter-type-list">\
                    </datalist>\
                    -->\
                    <select id="id-type-stat-filter-type" class="form-control">\
                    </select>\
                </div>\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <label class="te-padding-tb">审核时间起始点:</label>\
                </div>\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <input id="id-type-stat-filter-modify-time-start" \
                        class="form-control" type="date" />\
                </div>\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <label class="te-padding-tb">审核时间结束点:</label>\
                </div>\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <input id="id-type-stat-filter-modify-time-end" \
                        class="form-control" type="date" />\
                </div>\
            </div>\
            <br />\
            <div class="row">\
                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">\
                    <button class="btn btn-default" id="id-type-stat-filter-reset">\
                        恢复默认值\
                    </button>\
                    <button class="btn btn-primary" id="id-type-stat-filter-search">\
                        开始查询\
                    </button>\
                </div>\
            </div>\
        </div>\
    </div>\
    <hr />\
    ');

    //
    window.TEV.tpl_stat_content = _.template('\
    <%\
    var info = arguments[0];\
    var thead = info["thead"];\
    var tbody = info["tbody"];\
    %>\
    <br />\
    <table class="table table-striped">\
        <thead>\
            <tr>\
            <%\
            for (var thead_idx in thead) {\
                each_col = thead[thead_idx];\
            %>\
                <th><%=each_col %></th>\
            <%\
            }\
            %>\
            </tr>\
        </thead>\
        <tbody>\
        <%\
        for (var row_idx in tbody) {\
            var row = tbody[row_idx];\
        %>\
            <tr>\
            <%\
            for (var col_idx in row) {\
                var each_col = row[col_idx];\
            %>\
                <td><%=each_col %></td>\
            <%\
            }\
            %>\
            </tr>\
        <%\
        }\
        %>\
        </tbody>\
    </table>\
    ');

})();
