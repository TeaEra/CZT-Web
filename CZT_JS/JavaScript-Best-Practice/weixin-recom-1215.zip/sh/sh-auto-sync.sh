echo "######" >> ../nohup-auto-sync.out
date >> ../nohup-auto-sync.out
/usr/bin/python ../cgi-bin/api_mysql_art_sync.py >> ../nohup-auto-sync.out
