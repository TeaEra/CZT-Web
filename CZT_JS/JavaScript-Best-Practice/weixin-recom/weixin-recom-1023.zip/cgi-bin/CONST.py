#!/usr/bin/python
# _*_ coding: utf-8 _*_

#
# Belong to Hailong;
HOST = "10.134.30.154:10171"
#
# Belong to Hailong;
MONGO_USER_INFO = "10.12.143.209"
#
# Belong to Gary;
MONGO_ARTICLE = "10.134.37.31"
#
# Default port for pymongo;
MONGO_DEFAULT_PORT = 27012
