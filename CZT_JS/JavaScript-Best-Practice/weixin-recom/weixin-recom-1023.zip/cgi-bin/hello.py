#!/usr/bin/python

print "Content-Type: text/html"
print
print "<h3>Hello, world!</h3>"
