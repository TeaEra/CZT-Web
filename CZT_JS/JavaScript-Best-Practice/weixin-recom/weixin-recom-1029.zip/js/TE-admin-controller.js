/**
 * by chenzhengtong @ 2014-10-29
 */

(function () {
    "use strict";

    window.TEController = window.TEController || {};

    /**
     * Action:
     *   init 'verify';
     */
    window.TEController.action_init_verify = function () {
        //
        window.TEController.action_show_admin_navbar();
        //
        window.TEController.action_show_admin_main_content();
        //
        window.TEController.show_all_channels();
        //
        $(window.TEIDS.ADMIN_VERIFY_FILTER_BTN_SEARCH).bind(
            "click", 
            window.TEController.search_all_filter_conditions
        );
        //
        window.TEController.add_loading_effect();
        window.TEController.add_scroll_top_effect();
        //
        // First fetch when login;
        // Maybe should be disabled for effect;
        /*window.objs.admin_curr_channel = "HOT";
        window.TEController.action_api_umis_for_admin(
            window.objs.admin_curr_channel,
            window.TEController.admin_success_get_articles
        );*/
    };

    /**
     * Action:
     *   show admin navbar;
     */
    window.TEController.action_show_admin_navbar = function () {
        $(window.TEIDS.ADMIN_NAVBAR).html(window.TETemplate.tpl_admin_navbar());
    };

    /**
     * Action:
     *   show admin main content;
     */
    window.TEController.action_show_admin_main_content = function () {
        $(window.TEIDS.ADMIN_MAIN_CONTENT).html(
            window.TETemplate.tpl_admin_verify_filter()
            + window.TETemplate.tpl_admin_verify_article_list()
        );
    };

    /**
     * Getter:
     *   get all channels;
     */
    window.TEController.get_all_channels = function () {
        window.objs.channels = new Array();
        var from_list = window.objs.CATEGORIES;
        for (var category_idx in from_list) {
            for (var channel_idx in from_list[category_idx]['channels']) {
                window.objs.channels.push(from_list[category_idx]['channels'][channel_idx]);
            }
        }
    };

    /**
     * Setter:
     *   show all channels in filter;
     */
    window.TEController.show_all_channels = function () {
        //
        if (!window.objs.channels) {
            window.TEController.get_all_channels();
        }
        //
        var from_list = window.objs.channels;
        var out_html = "";
        for (var idx in from_list) {
            out_html += "<option>" + from_list[idx] + "</option>";
        }
        //
        $(window.TEIDS.ADMIN_VERIFY_FILTER_CHANNEL).html(out_html);
    };

    /**
     * Action:
     *   search all filter conditions;
     */
    window.TEController.search_all_filter_conditions = function () {
        //
        var channel =$(window.TEIDS.ADMIN_VERIFY_FILTER_CHANNEL).val();
        var status = $(window.TEIDS.ADMIN_VERIFY_FILTER_STATUS).val();
        var key_words = $(window.TEIDS.ADMIN_VERIFY_FILTER_KEY_WORD).val().split("|");
        var key_word_list = new Array();
        for (var idx in key_words) {
            var curr_key_word = key_words[idx];
            if (curr_key_word) {
                key_word_list.push(curr_key_word);
            }
        }
        var submitter = $(window.TEIDS.ADMIN_VERIFY_FILTER_SUBMITTER).val();
        var pub_time_start = $(window.TEIDS.ADMIN_VERIFY_FILTER_PUB_TIME_START).val();
        //
        window.objs.filter_conditions = {};
        window.objs.filter_conditions.channel = channel;
        //
        console.log(channel);
        console.log(status);
        console.log(key_word_list);
        console.log(submitter);
        console.log(pub_time_start);
        //
        if ((!window.objs.admin_curr_channel) || channel !== window.objs.admin_curr_channel) {
            //
            window.objs.admin_curr_channel = channel;
            //
            window.TEController.action_api_umis_for_admin(
                channel,
                window.TEController.admin_success_get_articles
            );
        }
        else {
            // no need to fetch again;
        }
        //
        $(window.TEIDS.ADMIN_VERIFY_FILTER_SWITCH).click();
    };

    /**
     * Setter:
     *   set conditions;
     */
    //

    /**
     * [umis]
     * API:
     *   ajax call api 'cgi-bin/api_umis.py';
     */
    window.TEController.action_api_umis_for_admin = function (channel, success_func) {
        $.ajax({
            url: "cgi-bin/api_umis.py",
            type: "post",
            data: "channel=" + channel,
            dataType: "json",
            success: function (data, status, jqxhr) {
                success_func(channel, data);
            },
            error: function (jqxhr, status, error) {
                alert(error);
            }
        });
    };

    /**
     * Action:
     *   success function after action_api_umis_for_admin;
     */
    window.TEController.admin_success_get_articles = function (channel, data) {
        window.objs.umis_data = JSON.parse(data);
        //
        // API
        window.TEController.action_api_pymongo_article(
            window.objs.umis_data[channel], 
            window.TEController.admin_success_get_detailed_articles
        );
    };

    /**
     * Action:
     *   success function after action_api_pymongo_article
     */
    window.TEController.admin_success_get_detailed_articles = function (data) {
        //console.log(data);
        //
        window.objs.admin_articles = data['articles'];
        //
        window.TEController.action_show_admin_articles();
    };

    /**
     * Action:
     *   show admin articles;
     */
    window.TEController.action_show_admin_articles = function () {
        //
        var filtered_articles = window.objs.admin_articles;
        //
        $(window.TEIDS.ADMIN_VERIFY_ARTICLE_LIST_CONTENT).html(
            window.TETemplate.tpl_admin_verify_article_list_content(
                filtered_articles
            )
        );
    };

    /**
     * Action:
     *   process modify modal;
     */

    /**
     * Action:
     *   record every selected checkbox;
     */

    /**
     * Getter:
     *   get all indexes of selected checkbox;
     */

    /**
     * Action:
     *   batch updating status according to selected indexes;
     */

    /**
     * Getter:
     *   get all status from selects, ready for sync;
     */

    /**
     * Action:
     *   sync all selected status;
     */

    /**
     * Action:
     *   clean out-dated data;
     */

})();
