/**
 * by chenzhengtong @ 2014.10.28
 */

(function () {
    "use strict";

    //
    window.TEIDS = window.TEIDS || {};
    //
    window.TEIDS.ADMIN_NAVBAR = "#id-admin-navbar";
    window.TEIDS.ADMIN_MAIN_CONTENT = "#id-admin-main-content";
    //
    window.TEIDS.ADMIN_BTN_VERIFY = "#id-admin-btn-verify";
    window.TEIDS.ADMIN_BTN_ARTICLE = "#id-admin-btn-article";
    window.TEIDS.ADMIN_BTN_CATEGORY = "#id-admin-btn-category";
    window.TEIDS.ADMIN_BTN_TOPIC_WORD = "#id-admin-btn-topic-word";
    window.TEIDS.ADMIN_BTN_KEY_WORD = "#id-admin-btn-key-word";
    window.TEIDS.ADMIN_BTN_OFFICIAL_ACCOUNT = "#id-admin-official-account";
    //
    window.TEIDS.ADMIN_COLLAPSED_NAVBAR = "#id-admin-collapsed-navbar";
    window.TEIDS.ADMIN_DETAILED_NAVBAR = "#id-admin-detailed-navbar";
    //
    // filter;
    window.TEIDS.ADMIN_VERIFY_FILTER_SWITCH = "#id-admin-verify-filter-switch";
    window.TEIDS.ADMIN_VERIFY_FILTER = "#id-admin-verify-filter";
    window.TEIDS.ADMIN_VERIFY_FILTER_BTN_SEARCH = "#id-admin-verify-filter-btn-search";
    window.TEIDS.ADMIN_VERIFY_FILTER_BTN_RESET = "#id-admin-verify-filter-btn-reset";
    window.TEIDS.ADMIN_VERIFY_FILTER_CHANNEL = "#id-admin-verify-filter-channel";
    window.TEIDS.ADMIN_VERIFY_FILTER_STATUS = "#id-admin-verify-filter-status";
    window.TEIDS.ADMIN_VERIFY_FILTER_KEY_WORD = "#id-admin-verify-filter-key-word";
    window.TEIDS.ADMIN_VERIFY_FILTER_SUBMITTER = "#id-admin-verify-filter-submitter";
    window.TEIDS.ADMIN_VERIFY_FILTER_PUB_TIME_START = "#id-admin-verify-filter-pub-time-start";
    window.TEIDS.ADMIN_VERIFY_FILTER_PUB_TIME_END = "#id-admin-verify-filter-pub-time-end";
    window.TEIDS.ADMIN_VERIFY_FILTER_DB_TIME_START = "#id-admin-verify-filter-db-time-start";
    window.TEIDS.ADMIN_VERIFY_FILTER_DB_TIME_END = "#id-admin-verify-filter-db-time-end";
    window.TEIDS.ADMIN_VERIFY_FILTER_VERIFY_TIME_START = "#id-admin-verify-filter-verify-time-start";
    window.TEIDS.ADMIN_VERIFY_FILTER_VERIFY_TIME_END = "#id-admin-verify-filter-verify-time-end";
    window.TEIDS.ADMIN_VERIFY_FILTER_ENABLE_TIME_START = "#id-admin-verify-filter-enable-time-start";
    window.TEIDS.ADMIN_VERIFY_FILTER_ENABLE_TIME_END = "#id-admin-verify-filter-enable-time-end";
    window.TEIDS.ADMIN_VERIFY_FILTER_DISABLE_TIME_START = "#id-admin-verify-filter-disable-time-start";
    window.TEIDS.ADMIN_VERIFY_FILTER_DISABLE_TIME_END = "#id-admin-verify-filter-disable-time-end";
    //
    // article list;
    window.TEIDS.ADMIN_VERIFY_ARTICLE_LIST_CONTENT
        = "#id-admin-verify-article-list-content";

    //
    window.TEController.action_init_verify();

})();
