/**
 * by chenzhengtong @ 2014.10.28
 */

(function () {
    "use strict";

    // namespace;
    window.TETemplate = window.TETemplate || {};

    //
    window.TETemplate.tpl_admin_navbar = _.template('\
    <!-- -->\
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">\
        <div class="container-fluid">\
            <!-- -->\
            <div class="navbar-header">\
                <button id="id-admin-collapsed-navbar" type="button" \
                        class="navbar-toggle collapsed" data-toggle="collapse" \
                        data-target="#id-admin-detailed-navbar">\
                    <span class="sr-only">Toggle navigation</span>\
                    <span class="icon-bar"></span>\
                    <span class="icon-bar"></span>\
                    <span class="icon-bar"></span>\
                </button>\
            </div>\
            <!-- -->\
            <div class="collapse navbar-collapse" id="id-admin-detailed-navbar">\
                <ul class="nav navbar-nav">\
                    <li class="dropdown">\
                        <a href="javascript:void(0);" class="dropdown-toggle" \
                                data-toggle="dropdown">\
                                后台系统<span class="caret"></span>\
                        </a>\
                        <ul class="dropdown-menu" role="menu">\
                            <li id="id-admin-btn-verify"><a href="javascript:void(0);">审核管理</a></li>\
                            <li id="id-admin-btn-article"><a href="javascript:void(0);">精品文章审核</a></li>\
                            <li id="id-admin-btn-category"><a href="javascript:void(0);">类别管理</a></li>\
                            <li id="id-admin-btn-topic-word"><a href="javascript:void(0);">主题词管理</a></li>\
                            <li id="id-admin-btn-key-word"><a href="javascript:void(0);">关键词管理</a></li>\
                            <li id="id-admin-btn-official-account"><a href="javascript:void(0);">公众账号管理</a></li>\
                        </ul>\
                    </li>\
                </ul>\
            </div>\
        </div>\
    </nav>\
    ');

    //
    window.TETemplate.tpl_admin_verify_filter = _.template('\
    <!-- -->\
    <div class="container">\
        <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24">\
            <div class="row">\
                <div class="panel panel-default">\
                    <div class="panel-heading">\
                        <h4 class="panel-title"><a id="id-admin-verify-filter-switch" data-toggle="collapse" href="#id-admin-verify-filter">条件查询</a></h4>\
                    </div>\
                    <div class="panel-collapse collapse" id="id-admin-verify-filter">\
                        <div class="panel-body">\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>类别:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <select id="id-admin-verify-filter-channel" class="form-control">\
                                    </select>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>发表时间起始点:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-pub-time-start" \
                                        class="form-control" type="date" />\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>发表时间结束点:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-pub-time-end" \
                                        class="form-control" type="date" />\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>首次审核:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <select id="id-admin-verify-filter-status" class="form-control">\
                                        <option value="-1">无要求</option>\
                                        <option value="0">未审核</option>\
                                        <option value="1">审核通过</option>\
                                        <option value="2">审核不通过</option>\
                                    </select>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>入后台时间起始点:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-db-time-start" \
                                        class="form-control" type="date" />\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>入后台时间结束点:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-db-time-end" \
                                        class="form-control" type="date" />\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>关键词:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-key-word" \
                                        class="form-control" placeholder="key_word" type="text" />\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>审核时间起始点:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-verify-time-start" \
                                        class="form-control" type="date" />\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>审核时间结束点</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-verify-time-end" \
                                        class="form-control" type="date" />\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>提交人:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-submitter" class="form-control" placeholder="submitter" type="text" />\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>生效时间起始点:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-enable-time-start" \
                                        class="form-control" type="date" />\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>生效时间结束点:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-enable-time-end" \
                                        class="form-control" type="date" />\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-4 col-lg-offset-8 col-md-4 col-md-offset-8 col-sm-4 col-sm-offset-8 col-xs-4 col-xs-offset-8">\
                                    <label>失效时间起始点:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-disable-time-start" \
                                        class="form-control" type="date" />\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <label>失效时间结束点:</label>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <input id="id-admin-verify-filter-disable-time-end" \
                                        class="form-control" type="date" />\
                                </div>\
                            </div>\
                            <hr />\
                            <div class="row">\
                                <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24">\
                                    <div class="btn-group">\
                                        <button type="submit" class="btn btn-default" id="id-admin-verify-filter-btn-reset" class="btn btn-default">恢复默认值</button>\
                                        <button type="submit" class="btn btn-primary" id="id-admin-verify-filter-btn-search" class="btn btn-default">开始查询</button>\
                                    </div>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                </div>\
            </div>\
        </div>\
    </div>\
    ');

    window.TETemplate.tpl_admin_verify_article_list = _.template('\
    <!-- -->\
    <div class="container">\
        <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24">\
            <div class="row">\
                <div class="pull-left btn-group">\
                    <button class="btn btn-default" data-toggle="modal" data-target="#id-admin-batch-verify-modal">批量审核</button>\
                    <!-- -->\
                    <div id="id-admin-batch-verify-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="id-admin-batch-verify-modal-title" aria-hidden="true" >\
                        <div class="modal-dialog modal-md">\
                            <div class="modal-content">\
                                <div class="modal-header">\
                                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\
                                    <h4 class="modal-title" id="id-admin-batch-verify-modal-title">批量审核</h4>\
                                </div>\
                                <div class="modal-body">\
                                    <div class="row te-padding-bottom">\
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                            <label>已选择数量:</label>\
                                        </div>\
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                            <p>0</p>\
                                        </div>\
                                    </div>\
                                    <div class="row te-padding-bottom">\
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                            <label>首次审核:</label>\
                                        </div>\
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                            <select class="form-control">\
                                                <option value="0">未审核</option>\
                                                <option value="1">审核通过</option>\
                                                <option value="2">审核不通过</option>\
                                            </select>\
                                        </div>\
                                    </div>\
                                </div>\
                                <div class="modal-footer">\
                                    <button type="button" class="btn btn-default" data-dismiss="modal">放弃操作</button>\
                                    <button type="button" class="btn btn-primary">保存修改</button>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                    <!-- -->\
                </div>\
                <div class="pull-right btn-group">\
                    <button class="btn btn-default">同步</button>\
                    <button class="btn btn-default">清理过期数据</button>\
                </div>\
            </div>\
            <br />\
            <br />\
            <br />\
            <div class="row">\
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">\
                </div>\
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                    <p>编号</p>\
                </div>\
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">\
                    <p>标题</p>\
                </div>\
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                    <p>阅读数</p>\
                </div>\
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                    <p>类型</p>\
                </div>\
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">\
                    <p>快速审核</p>\
                </div>\
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                    <p>关键词</p>\
                </div>\
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">\
                    <p>相同文章数</p>\
                </div>\
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                    <p>提交人</p>\
                </div>\
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                    <p>时间信息</p>\
                </div>\
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                    <p>操作</p>\
                </div>\
            </div>\
            <div id="id-admin-verify-article-list-content">\
            </div>\
        </div>\
    </div>\
    ');
    
    window.TETemplate.tpl_admin_verify_article_list_content = _.template('\
    <!-- -->\
    <%\
    var channel_list = window.objs.channels;\
    var articles = arguments[0];\
    var channel = window.objs.admin_curr_channel;\
    for (var art_idx in articles) {\
        var curr_art = articles[art_idx];\
        var uni_id = curr_art["_id"];\
        var uni_id_short = uni_id.substring(0, 6);\
        var title = curr_art["title"];\
        var link = curr_art["url"];\
        var img = curr_art["img_list"][0] || "";\
        var read_num = curr_art["read_num"];\
        var category = "";\
        var status = curr_art["status"];\
        var key_word_list = new Array();\
        var key_word_str = "";\
        curr_art["topic1"] ? key_word_list.push(curr_art["topic1"]): "";\
        curr_art["topic2"] ? key_word_list.push(curr_art["topic2"]): "";\
        curr_art["topic3"] ? key_word_list.push(curr_art["topic3"]): "";\
        key_word_str = key_word_list.join("|");\
        var same_num;\
        var submitter;\
        var pub_time = new Date(curr_art["page_time"]*1000);\
        var pub_time_html = \
            pub_time.getFullYear() + "-" + (pub_time.getMonth()+1) + "-" + pub_time.getDate();\
        var db_time = new Date(curr_art["op_time"]*1000);\
        var db_time_html = \
            db_time.getFullYear() + "-" + (db_time.getMonth()+1) + "-" + db_time.getDate();\
        var account = curr_art["account"];\
    %>\
    <hr />\
    <div class="row">\
        <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">\
            <input type="checkbox" />\
        </div>\
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
            <p><span title="<%=uni_id %>"><%=uni_id_short %>...</span></p>\
        </div>\
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">\
            <a href="<%=link %>" target="_blank"><%=title %><span class="hidden-span"><img class="img-responsive img-thumbnail" src="<%=img%>" alt="image here" /></span></a>\
        </div>\
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
            <p class="label label-warning"><%=read_num %></p>\
        </div>\
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
            <p class="hover-hand" data-toggle="modal" data-target="#id-admin-channel-modal-<%=art_idx %>"><%=channel %></p>\
            <!-- -->\
            <div id="id-admin-channel-modal-<%=art_idx %>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="id-admin-channel-modal-title" aria-hidden="true">\
                <div class="modal-dialog modal-md">\
                    <div class="modal-content">\
                        <div class="modal-header">\
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\
                            <h4 class="modal-title" id="id-admin-channel-modal-titile">类别修改</h4>\
                        </div>\
                        <div class="modal-body">\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <label>标题:</label>\
                                </div>\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <p><%=title %><p>\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <label>URL:</label>\
                                </div>\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <a href="<%=link %>" target="_blank"><%=link.substring(0,30) %>...</a>\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <label>类别:</label>\
                                </div>\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <select>\
                                    <%\
                                    for (var channel_idx in channel_list) {\
                                    %>\
                                        <option <%=(channel===channel_list[channel_idx]?"selected":"") %>><%=channel_list[channel_idx] %></option>\
                                    <%\
                                    }\
                                    %>\
                                    </select>\
                                </div>\
                            </div>\
                        </div>\
                        <div class="modal-footer">\
                            <button type="button" class="btn btn-default" data-dismiss="modal">放弃操作</button>\
                            <button type="button" class="btn btn-primary">保存修改</button>\
                        </div>\
                    </div>\
                </div>\
            </div>\
            <!-- -->\
        </div>\
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">\
            <select>\
                <option <%=(status===0?"selected":"")%>>未审核</option>\
                <option <%=(status===1?"selected":"")%>>审核通过</option>\
                <option <%=(status===2?"selected":"")%>>审核不通过</option>\
            </select>\
        </div>\
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
            <div class="hover-hand" data-toggle="modal" data-target="#id-admin-keyword-modal-<%=art_idx %>">\
            <%\
            for (var key_word_idx in key_word_list) {\
            %>\
            <div class="te-padding-bottom">\
                <span class="label label-default">\
                    <%=key_word_list[key_word_idx] %>\
                </span>\
            </div>\
            <%\
            }\
            if (key_word_list.length === 0) {\
            %>\
                无\
            <%\
            }\
            %>\
            </div>\
            <!-- -->\
            <div id="id-admin-keyword-modal-<%=art_idx %>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="id-admin-keyword-modal-title" aria-hidden="true">\
                <div class="modal-dialog modal-md">\
                    <div class="modal-content">\
                        <div class="modal-header">\
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\
                            <h4 class="modal-title" id="id-admin-keyword-modal-titile">关键词修改</h4>\
                        </div>\
                        <div class="modal-body">\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <label>标题:</label>\
                                </div>\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <p><%=title %><p>\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <label>URL:</label>\
                                </div>\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <a href="<%=link %>" target="_blank"><%=link.substring(0,30) %>...</a>\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <label>关键词:</label>\
                                </div>\
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
                                    <input class="form-control" type="text" value="<%=key_word_str %>" />\
                                </div>\
                            </div>\
                        </div>\
                        <div class="modal-footer">\
                            <button type="button" class="btn btn-default" data-dismiss="modal">放弃操作</button>\
                            <button type="button" class="btn btn-primary">保存修改</button>\
                        </div>\
                    </div>\
                </div>\
            </div>\
            <!-- -->\
        </div>\
        <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">\
            <a href="#">0</a>\
        </div>\
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
            <p>xxx</p>\
        </div>\
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
            <p>发表时间:<span class="pull-right"><%=pub_time_html %></span></p>\
            <p>入后台时间:<span class="pull-right"><%=db_time_html %></span></p>\
            <p>审核时间:<span class="pull-right"></span></p>\
            <p>生效时间:<span class="pull-right"></span></p>\
            <p>失效时间:<span class="pull-right"></span></p>\
        </div>\
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
            <button id="id-admin-article-btn-modify-<%=art_idx %>" data-toggle="modal" data-target="#id-admin-article-modal-<%=art_idx %>">修改</button>\
            <!-- -->\
            <div id="id-admin-article-modal-<%=art_idx %>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="id-admin-modal-title" aria-hidden="true">\
                <div class="modal-dialog modal-lg">\
                    <div class="modal-content">\
                        <div class="modal-header">\
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>\
                                <h4 class="modal-title" id="id-admin-modal-titile">文章信息修改</h4>\
                        </div>\
                        <div class="modal-body">\
                            <div class="row">\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">编号:</div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <p class="break-word" title="<%=uni_id %>"><%=uni_id.substring(0,10)  %>...</p>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">URL:</div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <a class="break-word" href="<%=link %>" target="_blank" title="<%=link %>"><%=link.substring(0,30) %>...</a>\
                                </div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">账号:</div>\
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                                    <p><%=account %></p>\
                                </div>\
                            </div>\
                            <hr />\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <label class="control-label">标题:</label>\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <input class="form-control" value="<%=title %>" title="<%=title %>" />\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <!--<label class="control-label">发表时间:</label>-->\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <!--<input class="form-control" type="datetime-local" />-->\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <label class="control-label">阅读数:</label>\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <input class="form-control" type="number" value="<%=read_num %>" />\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <!--<label class="control-label">入后台时间:</label>-->\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <!--<input class="form-control" type="datetime-local" />-->\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <label class="control-label">首次审核:</label>\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <select class="form-control">\
                                        <option <%=(status===0?"selected":"")%>>未审核</option>\
                                        <option <%=(status===1?"selected":"")%>>审核通过</option>\
                                        <option <%=(status===2?"selected":"")%>>审核不通过</option>\
                                    </select>\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <!--<label class="control-label">审核时间:</label>-->\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <!--<input class="form-control" type="datetime-local" />-->\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <label class="control-label">类别:</label>\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <select class="form-control">\
                                    <%\
                                    for (var channel_idx in channel_list) {\
                                    %>\
                                        <option <%=(channel===channel_list[channel_idx]?"selected":"") %>><%=channel_list[channel_idx] %></option>\
                                    <%\
                                    }\
                                    %>\
                                    </select>\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <label class="control-label">生效时间:</label>\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <input class="form-control" type="datetime-local" />\
                                </div>\
                            </div>\
                            <div class="row te-padding-bottom">\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <label class="control-label">关键词:</label>\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <input class="form-control" type="text" value="<%=key_word_str %>" />\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <label class="control-label">失效时间:</label>\
                                </div>\
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">\
                                    <input class="form-control" type="datetime-local" />\
                                </div>\
                            </div>\
                        </div>\
                        <div class="modal-footer">\
                            <button type="button" class="btn btn-default" data-dismiss="modal">放弃操作</button>\
                            <button type="button" class="btn btn-primary">保存修改</button>\
                        </div>\
                    </div>\
                </div>\
            </div>\
            <!-- -->\
        </div>\
    </div>\
    <%\
    }\
    %>\
    ');

})();
