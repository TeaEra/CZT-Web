/**
 * by CHEN Zhengtong @ 2014-10-22
 */

(function () {

    "use strict";

    // Bind loading effect
    window.TEController.add_loading_effect();

    // Init
    window.objs.umis_curr_btn = "#id-umis-btn-channel-0";
    // Init
    window.TEController.action_init_umis();

})();
