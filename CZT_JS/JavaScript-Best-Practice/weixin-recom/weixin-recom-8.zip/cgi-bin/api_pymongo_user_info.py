#!/usr/bin/python
# _*_ coding: utf-8 _*_

import pymongo
import cgitb
import cgi
import json


cgitb.enable()
fs = cgi.FieldStorage()
#
HOST = "10.12.143.209"
PORT = 27012

def get_mid():
    return fs['mid'].value

def get_user_info_by_id():
    #
    mid = get_mid()
    #
    connection = pymongo.Connection(HOST, PORT)
    db = connection.userDB
    collection = db.user_info
    condition = {"_id" : mid}
    curr_user = collection.find(condition)[0]
    #
    connection.close()
    #
    return curr_user

'''
'''
def to_utf8(curr_user):
    #
    mid = curr_user['_id']
    user_info = curr_user['user_info']
    has_set_channel = curr_user['has_set_channel']
    gender = curr_user['gender']
    last_refresh_time = curr_user['last_refresh_time']
    click_list = curr_user['click_list']
    favor_list = curr_user['favor_list']
    selected_channels = curr_user['selected_channels']
    #
    res = dict()
    res['_id'] = get_str_in_utf8(mid)
    res['user_info'] = get_str_in_utf8(user_info)
    res['has_set_channel'] = has_set_channel
    res['gender'] = gender
    res['last_refresh_time'] = last_refresh_time
    res['click_list'] = list()
    res['favor_list'] = list()
    res['selected_channels'] = list()
    for each_click in click_list:
        temp_click = dict()
        temp_click['url'] = get_str_in_utf8(each_click['url'])
        temp_click['type'] = get_str_in_utf8(each_click['type'])
        temp_click['topic_keywords'] = list()
        for each_keyword in each_click['topic_keywords']:
                temp_click['topic_keywords'].append(get_str_in_utf8(each_keyword))
        #
        res['click_list'].append(temp_click)
    for each_favor in favor_list:
        temp_favor = dict()
        temp_favor['title'] = get_str_in_utf8(each_favor['title'])
        temp_favor['link'] = get_str_in_utf8(each_favor['link'])
        temp_favor['img_list'] = get_str_in_utf8(each_favor['img_list'])
        temp_favor['pub_source'] = get_str_in_utf8(each_favor['pub_source'])
        temp_favor['pub_channel'] = get_str_in_utf8(each_favor['pub_channel'])
        temp_favor['favor_time'] = each_favor['favor_time']
        #
        res['favor_list'].append(temp_favor)
    for each_channel in selected_channels:
        res['selected_channels'].append(get_str_in_utf8(each_channel))
    #
    return res

def get_str_in_utf8(in_string):
    return in_string.decode("gbk", "ignore").encode("utf8")


#print "Content-Type: application/json; charset=utf-8"
print "Content-Type: application/json; charset=gbk"
print
print json.dumps(to_utf8(get_user_info_by_id()))
