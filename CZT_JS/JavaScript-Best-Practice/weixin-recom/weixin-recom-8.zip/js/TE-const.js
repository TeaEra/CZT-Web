
/**
 * Created by chenzhengtong on 2014/10/21.
 */

(function () {

    "use strict";

    //
    window.TEIDS = window.TEIDS || {};
    //
    // localStorage
    window.TEIDS.LS_MID = "mid";
    //
    // 'index.html'
    window.TEIDS.MAIN_CONTENT = "#id-main-content";
    window.TEIDS.INPUT_MID = "#id-input-mid";
    window.TEIDS.BTN_LOGIN = "#id-btn-login";
    window.TEIDS.ARTICLE_LIST = "#id-article-list";
    window.TEIDS.BTN_REFRESH = "#id-btn-refresh";
    window.TEIDS.BTN_LOGOUT = "#id-btn-logout";
    window.TEIDS.BTN_SCROLL_TOP = "#id-btn-scroll-top";
    window.TEIDS.LABEL_USER = "#id-label-user";
    window.TEIDS.CHANNEL_SELECTED = "#id-channel-selected";
    window.TEIDS.CHANNEL_UNSELECTED = "#id-channel-unselected";
    //
    // 'user.html'
    window.TEIDS.USER_MAIN_CONTENT = "#id-user-main-content";
    window.TEIDS.USER_BTN_CLICK = "#id-user-btn-click";
    window.TEIDS.USER_BTN_FAVOR = "#id-user-btn-favor";
    window.TEIDS.USER_BTN_CHANNEL = "#id-user-btn-channel";
    window.TEIDS.USER_CONTENT_LIST = "#id-user-content-list";
    window.TEIDS.USER_BTN_RELOAD = "#id-user-btn-reload";

    // Save data
    window.objs = window.objs || {};
    window.objs.user_curr_btn = window.TEIDS.USER_BTN_CLICK;

})();
