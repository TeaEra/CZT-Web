/**
 * Created by chenzhengtong on 2014/10/17.
 */

(function () {

    "use strict";

    /*
    //
    window.TEIDS = window.TEIDS || {};
    window.TEIDS.BTN_CLICK = "#id-btn-click";
    window.TEIDS.BTN_FAVOR = "#id-btn-favor";
    window.TEIDS.BTN_CHANNEL = "#id-btn-channel";
    window.TEIDS.CONTENT_LIST = "#id-content-list";
    //
    window.TEIDS.LS_MID = "mid";
    // Save data
    window.objs = window.objs || {};
    window.objs.curr_btn = window.TEIDS.BTN_CLICK;
    */

    // Check localStorage;
    if (window.localStorage.getItem(window.TEIDS.LS_MID)) {
        //
        window.TEController.action_show_user_info();
    }
    else {
        window.open("index.html", "_self");
    }
    

    // Bind loading effect
    window.TEController.add_loading_effect();

})();
