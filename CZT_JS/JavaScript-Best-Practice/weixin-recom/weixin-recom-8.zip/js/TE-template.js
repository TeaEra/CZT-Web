/**
 * Created by chenzhengtong on 2014/10/17.
 */

(function () {

    "use strict";

    window.TETemplate = window.TETemplate || {};


    window.TETemplate.tpl_main_content = _.template('\
    <%\
        var mid = window.localStorage.getItem("mid");\
    %>\
    <!-- nav bar -->\
    <nav class="navbar navbar-default navbar-fixed-top">\
        <div class="container">\
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
            <label class="label label-info" id="id-label-user">用户名：<%=mid%></label>\
            <label class="label label-danger">刷新倒计时：<span id="id-timer"></span></label>\
            <span class="pull-right">\
                <a class="btn btn-danger btn-sm" id="id-btn-logout">退出此次登录</a>\
            <span>\
        </div>\
        </div>\
    </nav>\
    <!--  -->\
    <div class="container">\
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
            <div class="panel panel-default">\
                <div class="panel-body">\
                    <p>\
                    冷启：\
                        <span id="id-channel-selected">\
                            <a class="btn btn-success" role="button">A</a>\
                            <a class="btn btn-primary" role="button">B</a>\
                            <a class="btn btn-danger" role="button">C</a>\
                            <a class="btn btn-default" role="button">D</a>\
                            <a class="btn btn-default" role="button">E</a>\
                            <a class="btn btn-default" role="button">F</a>\
                            <a class="btn btn-default" role="button">G</a>\
                            <a class="btn btn-default" role="button">H</a>\
                            <a class="btn btn-default" role="button">I</a>\
                            <a class="btn btn-default" role="button">J</a>\
                            <a class="btn btn-default" role="button">K</a>\
                            <a class="btn btn-default" role="button">L</a>\
                            <a class="btn btn-default" role="button">M</a>\
                            <a class="btn btn-default" role="button">N</a>\
                        </span>\
                    </p>\
                    <p>\
                    补充：\
                        <span id="id-channel-unselected">\
                            <a class="btn btn-default" role="button">a</a>\
                            <a class="btn btn-default" role="button">b</a>\
                            <a class="btn btn-default" role="button">c</a>\
                            <a class="btn btn-default" role="button">d</a>\
                            <a class="btn btn-default" role="button">e</a>\
                            <a class="btn btn-default" role="button">f</a>\
                            <a class="btn btn-default" role="button">g</a>\
                            <a class="btn btn-default" role="button">h</a>\
                            <a class="btn btn-default" role="button">i</a>\
                            <a class="btn btn-default" role="button">j</a>\
                            <a class="btn btn-default" role="button">k</a>\
                            <a class="btn btn-default" role="button">l</a>\
                            <a class="btn btn-default" role="button">m</a>\
                            <a class="btn btn-default" role="button">n</a>\
                        </span>\
                    </p>\
                    <hr />\
                    <p>\
                        <a class="btn btn-primary" role="button" id="id-btn-refresh">刷新</a>\
                    </p>\
                </div>\
            </div>\
        </div>\
    </div>\
    <!-- -->\
    <div class="container">\
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
            <div class="table-responsive">\
                <table class="table table-fixed-layout">\
                    <thead>\
                        <tr>\
                            <td>标题</td>\
                            <td>类别</td>\
                            <td>图片</td>\
                            <td>关键词</td>\
                            <td>理由</td>\
                            <td>审核状态</td>\
                            <td>操作</td>\
                        </tr>\
                    </thead>\
                    <tbody id="id-article-list">\
                        \
                    </tbody>\
                </table>\
            </div>\
        </div>\
    </div>\
    <!-- -->\
    <div id="id-btn-scroll-top" class="scroll-top">\
        <i class="glyphicon glyphicon-chevron-up"></i>\
    </div>\
    ');

    window.TETemplate.tpl_init = _.template('\
    <!-- -->\
    <div class="container">\
        <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-8 col-xs-offset-2">\
            <div class="panel panel-default">\
                <div class="panel-body">\
                    <fieldset>\
                        <div class="form-group">\
                            <input class="form-control" placeholder="MID" id="id-input-mid" type="text">\
                        </div>\
                        <input class="btn btn-lg btn-success btn-block" type="submit" value="LOGIN" \
                        id="id-btn-login">\
                    </fieldset>\
                </div>\
            </div>\
        </div>\
    </div>\
    ');

    window.TETemplate.tpl_user_init = _.template('\
    <div class="container">\
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">\
            <div class="btn-group">\
                <button class="btn btn-primary btn-lg" id="id-user-btn-reload">刷新数据</button>\
            </div>\
            <br />\
            <br />\
            <div class="text-center">\
                <div class="btn-group">\
                    <button class="btn btn-danger" id="id-user-btn-click">阅读列表</button>\
                    <button class="btn btn-default" id="id-user-btn-favor">收藏列表</button>\
                    <button class="btn btn-default" id="id-user-btn-channel">已选频道</button>\
                </div>\
            </div>\
        </div>\
    </div>\
    <br />\
    <div class="container">\
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="id-user-content-list">\
        </div>\
    </div>\
    <!-- -->\
    <div id="id-btn-scroll-top" class="scroll-top">\
        <i class="glyphicon glyphicon-chevron-up"></i>\
    </div>\
    ');

    window.TETemplate.tpl_click_list = _.template('\
    <%\
    var click_list = arguments[0];\
    for (var idx in click_list) {\
        var each_click = click_list[idx];\
        var url = each_click["url"];\
        var type = each_click["type"] || "temporally nothing";\
        var topic_keywords = each_click["topic_keywords"] || "temporally nothing";\
    %>\
        <div class="row">\
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                <p style="word-wrap: break-word;">\
                    <a href="<%=url %>" target="_blank"><%=url %></a>\
                </p>\
            </div>\
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><%=type %></div>\
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"></div>\
        </div>\
    <%\
        if (idx != click_list.length -1) {\
    %>\
            <hr />\
    <%\
        }\
    }\
    %>\
    ');

    window.TETemplate.tpl_favor_list = _.template('\
    <%\
    var favor_list = arguments[0];\
    for (var idx in favor_list) {\
        var each_favor = favor_list[idx];\
        var favor_time = each_favor["favor_time"];\
        var img_list = each_favor["img_list"];\
        var link = each_favor["link"];\
        var pub_channel = each_favor["pub_channel"];\
        var pub_source = each_favor["pub_source"];\
        var title = each_favor["title"];\
    %>\
        <div class="row">\
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                <p class="break-word">\
                    <a href="<%=link %>" target="_blank"><%=title %></a>\
                </p>\
            </div>\
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                <p class="break-word"><%=pub_source %></p>\
            </div>\
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                <p class="break-word"><%=pub_channel %></p>\
            </div>\
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">\
                <img class="img-responsive img-thumbnail" src="<%=img_list %>" />\
            </div>\
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">\
                <p class="break-word"><%=new Date(favor_time) %></p>\
            </div>\
        </div>\
    <%\
    }\
    %>\
    ');

    window.TETemplate.tpl_channel_list = _.template('\
    <h3>已选择频道:</h3>\
    <div>\
    <%\
    var channel_list = arguments[0];\
    for (var idx in channel_list) {\
        var each_channel = channel_list[idx];\
    %>\
        <div style="display: inline; font-size: 2em; padding-bottm: 0.5em;">\
            <span class="label label-success"><%=each_channel %></span>&nbsp;&nbsp;\
        </div>\
    <%\
    }\
    %>\
    </div>\
    ');

})();
